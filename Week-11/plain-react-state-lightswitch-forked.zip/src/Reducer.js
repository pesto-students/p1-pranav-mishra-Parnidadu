import { createStore } from "redux";
const intialState = true;
const reducerFun = (currentState = intialState, action) => {
  switch (action.type) {
    case "TOGGLE":
      return !currentState;
    default:
      return currentState;
  }
};

export const store = createStore(reducerFun);
console.log(store.getState());
