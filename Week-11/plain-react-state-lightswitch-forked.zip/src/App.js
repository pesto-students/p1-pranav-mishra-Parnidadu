// import "./styles.css";
import { store } from "./Reducer";
// import { useState } from "react";
console.log(store.getState());

export default function App() {
  const flipLight = () => {
    store.dispatch({ type: "TOGGLE" });
  };
  const lightedness = store.getState() ? "lit" : "dark";

  return (
    <div className="App">
      <div className={`room ${lightedness}`}>
        the room is {lightedness}
        <br />
        <button onClick={flipLight}>flip</button>
      </div>
    </div>
  );
}

// ÷export default App;
